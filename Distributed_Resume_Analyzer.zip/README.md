
# Distributed Resume Analyzer over TCP with TF-IDF Ranking

## Overview
A basic yet unique system that:
- Transfers resumes from a client to a server via TCP/IP.
- Distributes the task of resume evaluation to multiple worker nodes.
- Uses TF-IDF and ML models to rank resumes against job descriptions.
- Includes Linux shell scripts for monitoring and automation.

## Tech Stack
- Python (Sockets, Threading, scikit-learn, TF-IDF)
- Bash (automation scripts)
- OS: Unix/Linux

## Structure
- `client/` - Sends resumes to server
- `server/` - Accepts and distributes resumes to workers
- `workers/` - Evaluate resumes
- `scripts/` - Bash scripts for health checks, logging, cleanup
- `data/` - Sample resumes and job descriptions

## How to Run
1. Run the server: `python3 server/main.py`
2. Run workers: `python3 workers/worker1.py`, etc.
3. Run client: `python3 client/client.py`
4. Scripts: `bash scripts/monitor.sh`, etc.
