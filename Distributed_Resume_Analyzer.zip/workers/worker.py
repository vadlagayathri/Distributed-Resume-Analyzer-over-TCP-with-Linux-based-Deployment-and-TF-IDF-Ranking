
import time
import os
import queue
from sklearn.feature_extraction.text import TfidfVectorizer

def analyze_resume(file_path, job_desc_path="data/job_description.txt"):
    with open(file_path, 'r', encoding='utf-8') as f1, open(job_desc_path, 'r', encoding='utf-8') as f2:
        resume_text = f1.read()
        job_desc_text = f2.read()

    corpus = [resume_text, job_desc_text]
    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(corpus)
    similarity = (tfidf_matrix * tfidf_matrix.T).A[0,1]
    print(f"Similarity score for {file_path}: {similarity:.2f}")
    return similarity

def watch_folder(folder="received"):
    processed = set()
    while True:
        if not os.path.exists(folder):
            os.makedirs(folder)
        files = os.listdir(folder)
        for file in files:
            if file not in processed:
                file_path = os.path.join(folder, file)
                score = analyze_resume(file_path)
                processed.add(file)
        time.sleep(5)

if __name__ == "__main__":
    watch_folder()
