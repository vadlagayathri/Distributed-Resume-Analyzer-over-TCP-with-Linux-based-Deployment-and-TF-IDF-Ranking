
import socket
import threading
import queue
import os

task_queue = queue.Queue()

def handle_client(conn, addr):
    print(f"Connected by {addr}")
    data = conn.recv(4096)
    if not os.path.exists("received"):
        os.makedirs("received")
    file_path = f"received/resume_{addr[1]}.txt"
    with open(file_path, "wb") as f:
        f.write(data)
    print(f"Saved resume from {addr} to {file_path}")
    task_queue.put(file_path)
    conn.sendall(b"Resume received and queued for analysis.")

def server():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('localhost', 9999))
        s.listen()
        print("Server listening on port 9999...")
        while True:
            conn, addr = s.accept()
            threading.Thread(target=handle_client, args=(conn, addr)).start()

if __name__ == "__main__":
    server()
