
import socket

def send_resume(file_path):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect(('localhost', 9999))
        with open(file_path, 'rb') as f:
            data = f.read()
        s.sendall(data)
        print("Resume sent successfully.")
        response = s.recv(4096)
        print("Server response:", response.decode())

if __name__ == "__main__":
    send_resume("resume.txt")
